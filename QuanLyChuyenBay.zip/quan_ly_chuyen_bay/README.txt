pip install -r requirements.txt
--Run code
python app.py